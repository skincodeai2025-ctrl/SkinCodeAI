-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 17, 2025 at 04:15 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `skincodeia1`
--

-- --------------------------------------------------------

--
-- Table structure for table `citas`
--

CREATE TABLE `citas` (
  `id_cita` int(11) NOT NULL,
  `id_usuario_cliente` int(11) NOT NULL,
  `id_usuario_tatuador` int(11) DEFAULT NULL,
  `id_servicio` int(11) DEFAULT NULL,
  `estado` enum('solicitud','programada','confirmada','cancelada','realizada') NOT NULL DEFAULT 'solicitud',
  `fecha_hora_inicio` datetime DEFAULT NULL,
  `fecha_hora_fin` datetime DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `notas_cliente` text DEFAULT NULL,
  `notas_internas` text DEFAULT NULL,
  `url_referencia` varchar(300) DEFAULT NULL,
  `pago_estado` enum('pendiente','pagado','reembolsado') DEFAULT 'pendiente',
  `pago_monto` decimal(10,2) DEFAULT NULL,
  `pago_fecha` datetime DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `citas`
--

INSERT INTO `citas` (`id_cita`, `id_usuario_cliente`, `id_usuario_tatuador`, `id_servicio`, `estado`, `fecha_hora_inicio`, `fecha_hora_fin`, `precio`, `notas_cliente`, `notas_internas`, `url_referencia`, `pago_estado`, `pago_monto`, `pago_fecha`, `creado_en`, `actualizado_en`) VALUES
(1, 2, 3, 1, 'solicitud', NULL, NULL, 80000.00, 'Quiero un tatuaje pequeño en el brazo', NULL, NULL, 'pendiente', NULL, NULL, '2025-10-15 23:16:17', NULL),
(2, 2, NULL, 2, 'programada', NULL, NULL, 150000.00, 'Tatuaje mediano en la espalda', NULL, NULL, 'pendiente', NULL, NULL, '2025-10-15 23:16:17', NULL),
(3, 4, 5, 1, 'cancelada', '2025-10-17 10:24:00', '2025-10-17 00:27:00', NULL, 'chino', 'no tengo e recurso', 'https://th.bing.com/th/id/OIP.r7dgVEjU05OO6E9eANmTwQHaH_?w=196&h=212&c=7&r=0&o=7&cb=12&pid=1.7&rm=3', 'pendiente', NULL, NULL, '2025-10-16 00:53:14', '2025-10-16 03:35:35'),
(4, 4, 5, 1, 'realizada', '2025-10-23 11:38:00', '2025-10-24 11:38:00', 80000.00, 'mini', NULL, 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAlAMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAACAwABBAUGB//EADMQA', 'pagado', 80000.00, '2025-10-23 23:47:00', '2025-10-16 03:36:37', '2025-10-16 03:46:51'),
(5, 6, 5, 1, 'confirmada', '2025-10-17 01:24:00', '2025-10-17 02:25:00', 80000.00, 'hghkhku', NULL, NULL, 'pendiente', NULL, NULL, '2025-10-16 16:21:29', '2025-10-16 17:02:27'),
(6, 6, 7, 2, 'realizada', '2025-10-18 02:58:00', '2025-10-18 02:58:00', 150000.00, 'iuhfgiue', NULL, NULL, 'pagado', 150000.00, '2025-10-17 02:03:00', '2025-10-16 16:48:27', '2025-10-16 17:01:28');

-- --------------------------------------------------------

--
-- Table structure for table `clientes`
--

CREATE TABLE `clientes` (
  `id_cliente` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `primer_apellido` varchar(100) DEFAULT NULL,
  `segundo_apellido` varchar(100) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `direccion` text DEFAULT NULL,
  `fecha_naci` date DEFAULT NULL,
  `nickname` varchar(50) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `clientes`
--

INSERT INTO `clientes` (`id_cliente`, `id_usuario`, `nombre`, `primer_apellido`, `segundo_apellido`, `telefono`, `direccion`, `fecha_naci`, `nickname`, `creado_en`) VALUES
(1, 2, 'Juan', 'Pérez', NULL, '3001234567', NULL, '1990-05-15', NULL, '2025-10-15 23:16:17'),
(2, 4, 'edward', 'quinones', 'valenzuela', '3152858236', 'guayacanes', '1974-08-25', NULL, '2025-10-16 00:34:12'),
(3, 6, 'cliente 3', 'cliente 3', 'cleinte 3', '1111111111111', 'call', '2000-06-06', NULL, '2025-10-16 16:19:35');

-- --------------------------------------------------------

--
-- Table structure for table `credenciales`
--

CREATE TABLE `credenciales` (
  `id_usuario` int(11) NOT NULL,
  `hash_clave` varchar(255) NOT NULL,
  `salt` varchar(255) NOT NULL,
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `credenciales`
--

INSERT INTO `credenciales` (`id_usuario`, `hash_clave`, `salt`, `actualizado_en`) VALUES
(1, '$2b$10$N9qo8uLOickgx2ZMRZoMye/Lo10Ng/o154/X/TbwRqinfsLhc6EN2', '$2b$10$N9qo8uLOickgx2ZMRZoMye', '2025-10-16 00:03:47'),
(2, '$2b$10$N9qo8uLOickgx2ZMRZoMye/Lo10Ng/o154/X/TbwRqinfsLhc6EN2', '$2b$10$N9qo8uLOickgx2ZMRZoMye', '2025-10-16 00:03:47'),
(3, '$2b$10$N9qo8uLOickgx2ZMRZoMye/Lo10Ng/o154/X/TbwRqinfsLhc6EN2', '$2b$10$N9qo8uLOickgx2ZMRZoMye', '2025-10-16 00:03:47'),
(4, '$2b$10$HJPDr47jGHvmBsN9/JND4udX6SXVRoclzSNNkzMdWXvf/2sCDm8oi', '$2b$10$HJPDr47jGHvmBsN9/JND4u', '2025-10-16 00:31:40'),
(5, '$2b$10$iI5jD1bdOPBMy8Q502QhMOqClHgt9vFNuO5591Vv2jOS6MUCz0Vb.', '$2b$10$iI5jD1bdOPBMy8Q502QhMO', '2025-10-16 00:58:23'),
(6, '$2b$10$/UeExq.Yi2E2QVJOR4yefeJghyI13DiWZDWOZXrivWe93080EXlZK', '$2b$10$/UeExq.Yi2E2QVJOR4yefe', '2025-10-16 16:17:43'),
(7, '$2b$10$KGlsboSP2YHWJ9bgCSDDCO2L5en11DMmleiuGHyBObWSgIlN6w93m', '$2b$10$KGlsboSP2YHWJ9bgCSDDCO', '2025-10-16 16:44:24');

-- --------------------------------------------------------

--
-- Table structure for table `notificaciones`
--

CREATE TABLE `notificaciones` (
  `id_notificacion` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_cita` int(11) DEFAULT NULL,
  `tipo` enum('cita_creada','cita_programada','cita_confirmada','cita_cancelada','cita_realizada','recordatorio','pago_recibido','mensaje') NOT NULL,
  `titulo` varchar(200) NOT NULL,
  `mensaje` text NOT NULL,
  `leida` tinyint(1) NOT NULL DEFAULT 0,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notificaciones`
--

INSERT INTO `notificaciones` (`id_notificacion`, `id_usuario`, `id_cita`, `tipo`, `titulo`, `mensaje`, `leida`, `fecha_creacion`, `creado_en`) VALUES
(1, 4, 3, '', '❌ Cita cancelada', 'Tu cita ha sido cancelada. Puedes agendar una nueva cuando lo desees.', 0, '2025-10-16 03:35:35', '2025-10-16 03:35:35'),
(2, 5, 3, '', '❌ Cita cancelada', 'La cita con edward ha sido cancelada.', 0, '2025-10-16 03:35:35', '2025-10-16 03:35:35'),
(3, 4, 4, '', '📋 Nueva solicitud de cita', 'Tu solicitud de cita ha sido registrada. Te notificaremos cuando sea programada.', 0, '2025-10-16 03:36:37', '2025-10-16 03:36:37'),
(4, 4, 4, '', '📅 Cita programada', 'Tu cita ha sido programada para el 23/10/2025, 11:38:00.', 0, '2025-10-16 03:37:51', '2025-10-16 03:37:51'),
(5, 4, 4, '', '✅ Cita confirmada', 'Tu cita ha sido confirmada. Te esperamos el 23/10/2025, 11:38:00.', 0, '2025-10-16 03:38:52', '2025-10-16 03:38:52'),
(6, 5, 4, '', '✅ Cliente confirmó cita', 'edward confirmó la cita del 23/10/2025, 11:38:00.', 0, '2025-10-16 03:38:52', '2025-10-16 03:38:52'),
(7, 4, 4, '', '🎉 Cita completada', 'Tu cita ha sido completada exitosamente. ¡Gracias por confiar en nosotros!', 0, '2025-10-16 03:46:51', '2025-10-16 03:46:51'),
(8, 6, 5, '', '📋 Nueva solicitud de cita', 'Tu solicitud de cita ha sido registrada. Te notificaremos cuando sea programada.', 0, '2025-10-16 16:21:29', '2025-10-16 16:21:29'),
(9, 6, 5, '', '📅 Cita programada', 'Tu cita ha sido programada para el 17/10/2025, 1:24:00.', 0, '2025-10-16 16:23:13', '2025-10-16 16:23:13'),
(10, 6, 6, '', '📋 Nueva solicitud de cita', 'Tu solicitud de cita ha sido registrada. Te notificaremos cuando sea programada.', 0, '2025-10-16 16:48:27', '2025-10-16 16:48:27'),
(11, 6, 6, '', '📅 Cita programada', 'Tu cita ha sido programada para el 18/10/2025, 2:58:00.', 0, '2025-10-16 16:56:36', '2025-10-16 16:56:36'),
(12, 6, 6, '', '✅ Cita confirmada', 'Tu cita ha sido confirmada. Te esperamos el 18/10/2025, 2:58:00.', 0, '2025-10-16 16:58:04', '2025-10-16 16:58:04'),
(13, 7, 6, '', '✅ Cliente confirmó cita', 'cliente 3 confirmó la cita del 18/10/2025, 2:58:00.', 0, '2025-10-16 16:58:04', '2025-10-16 16:58:04'),
(14, 6, 6, '', '🎉 Cita completada', 'Tu cita ha sido completada exitosamente. ¡Gracias por confiar en nosotros!', 0, '2025-10-16 17:01:28', '2025-10-16 17:01:28'),
(15, 6, 5, '', '✅ Cita confirmada', 'Tu cita ha sido confirmada. Te esperamos el 17/10/2025, 1:24:00.', 0, '2025-10-16 17:02:27', '2025-10-16 17:02:27'),
(16, 5, 5, '', '✅ Cliente confirmó cita', 'cliente 3 confirmó la cita del 17/10/2025, 1:24:00.', 0, '2025-10-16 17:02:27', '2025-10-16 17:02:27');

-- --------------------------------------------------------

--
-- Table structure for table `pagos`
--

CREATE TABLE `pagos` (
  `id_pago` int(11) NOT NULL,
  `id_cita` int(11) NOT NULL,
  `monto` decimal(10,2) NOT NULL,
  `metodo` enum('efectivo','electronico','bitcoin') NOT NULL DEFAULT 'efectivo',
  `estado` enum('pendiente','completado','fallido','reembolsado') NOT NULL DEFAULT 'pendiente',
  `referencia` varchar(100) DEFAULT NULL,
  `fecha_pago` datetime NOT NULL DEFAULT current_timestamp(),
  `notas` text DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id_rol` int(11) NOT NULL,
  `nombre` enum('cliente','tatuador','soporte') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id_rol`, `nombre`) VALUES
(1, 'cliente'),
(2, 'tatuador'),
(3, 'soporte');

-- --------------------------------------------------------

--
-- Table structure for table `servicios`
--

CREATE TABLE `servicios` (
  `id_servicio` int(11) NOT NULL,
  `nombre` varchar(120) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `servicios`
--

INSERT INTO `servicios` (`id_servicio`, `nombre`, `descripcion`, `precio`, `activo`, `creado_en`) VALUES
(1, 'Tatuaje Mini (2-5cm)', 'Diseño muy pequeño, símbolos o letras. 30-60 min.', 80000.00, 1, '2025-10-15 23:16:17'),
(2, 'Tatuaje Pequeño (5-10cm)', 'Diseño simple en muñeca, tobillo. 1-2 horas.', 150000.00, 1, '2025-10-15 23:16:17'),
(3, 'Tatuaje Mediano (10-20cm)', 'Diseño con detalle en brazo o pierna. 2-4 horas.', 300000.00, 1, '2025-10-15 23:16:17'),
(4, 'Piercing Lóbulo', 'Perforación básica en lóbulo de oreja. Cicatrización: 1-2 meses.', 30000.00, 1, '2025-10-15 23:16:17'),
(5, 'Piercing Helix', 'Perforación en cartílago superior. Cicatrización: 3-6 meses.', 40000.00, 1, '2025-10-15 23:16:17');

-- --------------------------------------------------------

--
-- Table structure for table `tatuadores`
--

CREATE TABLE `tatuadores` (
  `id_tatuador` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `nombre_artistico` varchar(100) DEFAULT NULL,
  `nombre_real` varchar(100) DEFAULT NULL,
  `especialidad` varchar(200) DEFAULT NULL,
  `especialidades` text DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `experiencia_anos` int(11) DEFAULT NULL,
  `portfolio_url` varchar(300) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tatuadores`
--

INSERT INTO `tatuadores` (`id_tatuador`, `id_usuario`, `nombre`, `nombre_artistico`, `nombre_real`, `especialidad`, `especialidades`, `bio`, `experiencia_anos`, `portfolio_url`, `telefono`, `activo`, `creado_en`) VALUES
(1, 3, 'Carlos', NULL, NULL, NULL, 'Realismo, Tradicional', NULL, 5, NULL, NULL, 1, '2025-10-15 23:16:17'),
(2, 5, '', 'caperucita', 'johana', 'Minimalista', NULL, NULL, NULL, NULL, '1234567890', 1, '2025-10-16 01:18:26'),
(3, 7, '', 'salpulido', 'xxxxxx', 'Old School', NULL, NULL, NULL, NULL, '111111111111111', 1, '2025-10-16 16:52:51');

-- --------------------------------------------------------

--
-- Table structure for table `tatuajes_cliente`
--

CREATE TABLE `tatuajes_cliente` (
  `id_tatuaje` int(11) NOT NULL,
  `id_usuario_cliente` int(11) NOT NULL,
  `ubicacion_cuerpo` varchar(100) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `fecha_realizacion` date DEFAULT NULL,
  `nombre_tatuador` varchar(100) DEFAULT NULL,
  `url_imagen` varchar(300) DEFAULT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tatuajes_cliente`
--

INSERT INTO `tatuajes_cliente` (`id_tatuaje`, `id_usuario_cliente`, `ubicacion_cuerpo`, `descripcion`, `fecha_realizacion`, `nombre_tatuador`, `url_imagen`, `categoria`, `creado_en`, `actualizado_en`) VALUES
(1, 4, 'pierna', 'leon', '2024-01-01', 'leon', 'https://tse2.mm.bing.net/th/id/OIP.9Q_PAmr1wAP72bcKeJdOBQHaJP?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3', 'japonés', '2025-10-16 00:51:36', NULL),
(2, 5, 'pie', 'tatuaje en el pies', NULL, NULL, 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAIBAQEBAQIBAQECAgICAgQDAgICAgUEBAMEBgUGBgYFBgYGBwkIBgcJBwYGCAsICQoKCgoKBggLDAsKDAkKCgr/2wBDAQICAgICAgUDAwUKBwYHCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgr/wAARCAHgAWgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcIC', 'acuarela', '2025-10-16 03:11:49', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `email` varchar(150) NOT NULL,
  `estado` enum('activo','inactivo') NOT NULL DEFAULT 'activo',
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `email`, `estado`, `creado_en`) VALUES
(1, 'admin@skincodeia1.com', 'activo', '2025-10-15 23:16:17'),
(2, 'cliente@test.com', 'activo', '2025-10-15 23:16:17'),
(3, 'tatuador@test.com', 'activo', '2025-10-15 23:16:17'),
(4, 'cliente2@test.com', 'activo', '2025-10-16 00:31:40'),
(5, 'tatuador2@test.com', 'activo', '2025-10-16 00:58:23'),
(6, 'cliente3@test.com', 'activo', '2025-10-16 16:17:43'),
(7, 'tatuador4@test.com', 'activo', '2025-10-16 16:44:24');

-- --------------------------------------------------------

--
-- Table structure for table `usuario_roles`
--

CREATE TABLE `usuario_roles` (
  `id_usuario` int(11) NOT NULL,
  `id_rol` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `usuario_roles`
--

INSERT INTO `usuario_roles` (`id_usuario`, `id_rol`) VALUES
(1, 3),
(2, 1),
(3, 2),
(4, 1),
(5, 2),
(6, 1),
(7, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `citas`
--
ALTER TABLE `citas`
  ADD PRIMARY KEY (`id_cita`),
  ADD KEY `fk_citas_servicio` (`id_servicio`),
  ADD KEY `idx_citas_cliente` (`id_usuario_cliente`),
  ADD KEY `idx_citas_tatuador` (`id_usuario_tatuador`),
  ADD KEY `idx_citas_estado` (`estado`),
  ADD KEY `idx_citas_fecha_inicio` (`fecha_hora_inicio`);

--
-- Indexes for table `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id_cliente`),
  ADD UNIQUE KEY `id_usuario` (`id_usuario`),
  ADD KEY `idx_clientes_usuario` (`id_usuario`),
  ADD KEY `idx_clientes_nombre` (`nombre`);

--
-- Indexes for table `credenciales`
--
ALTER TABLE `credenciales`
  ADD PRIMARY KEY (`id_usuario`);

--
-- Indexes for table `notificaciones`
--
ALTER TABLE `notificaciones`
  ADD PRIMARY KEY (`id_notificacion`),
  ADD KEY `idx_notif_usuario` (`id_usuario`),
  ADD KEY `idx_notif_leida` (`leida`),
  ADD KEY `idx_notif_cita` (`id_cita`),
  ADD KEY `idx_notif_tipo` (`tipo`);

--
-- Indexes for table `pagos`
--
ALTER TABLE `pagos`
  ADD PRIMARY KEY (`id_pago`),
  ADD KEY `idx_pagos_cita` (`id_cita`),
  ADD KEY `idx_pagos_estado` (`estado`),
  ADD KEY `idx_pagos_fecha` (`fecha_pago`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id_rol`),
  ADD UNIQUE KEY `nombre` (`nombre`);

--
-- Indexes for table `servicios`
--
ALTER TABLE `servicios`
  ADD PRIMARY KEY (`id_servicio`),
  ADD KEY `idx_servicios_activo` (`activo`),
  ADD KEY `idx_servicios_nombre` (`nombre`);

--
-- Indexes for table `tatuadores`
--
ALTER TABLE `tatuadores`
  ADD PRIMARY KEY (`id_tatuador`),
  ADD UNIQUE KEY `id_usuario` (`id_usuario`),
  ADD KEY `idx_tatuadores_usuario` (`id_usuario`),
  ADD KEY `idx_tatuadores_activo` (`activo`);

--
-- Indexes for table `tatuajes_cliente`
--
ALTER TABLE `tatuajes_cliente`
  ADD PRIMARY KEY (`id_tatuaje`),
  ADD KEY `idx_tatuajes_cliente_usuario` (`id_usuario_cliente`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `usuario_roles`
--
ALTER TABLE `usuario_roles`
  ADD PRIMARY KEY (`id_usuario`,`id_rol`),
  ADD KEY `fk_usuario_roles_rol` (`id_rol`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `citas`
--
ALTER TABLE `citas`
  MODIFY `id_cita` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id_cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `notificaciones`
--
ALTER TABLE `notificaciones`
  MODIFY `id_notificacion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `pagos`
--
ALTER TABLE `pagos`
  MODIFY `id_pago` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id_rol` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `servicios`
--
ALTER TABLE `servicios`
  MODIFY `id_servicio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tatuadores`
--
ALTER TABLE `tatuadores`
  MODIFY `id_tatuador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tatuajes_cliente`
--
ALTER TABLE `tatuajes_cliente`
  MODIFY `id_tatuaje` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `citas`
--
ALTER TABLE `citas`
  ADD CONSTRAINT `fk_citas_cliente` FOREIGN KEY (`id_usuario_cliente`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_citas_servicio` FOREIGN KEY (`id_servicio`) REFERENCES `servicios` (`id_servicio`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_citas_tatuador` FOREIGN KEY (`id_usuario_tatuador`) REFERENCES `usuarios` (`id_usuario`) ON DELETE SET NULL;

--
-- Constraints for table `clientes`
--
ALTER TABLE `clientes`
  ADD CONSTRAINT `fk_clientes_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE;

--
-- Constraints for table `credenciales`
--
ALTER TABLE `credenciales`
  ADD CONSTRAINT `fk_credenciales_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE;

--
-- Constraints for table `notificaciones`
--
ALTER TABLE `notificaciones`
  ADD CONSTRAINT `fk_notif_cita` FOREIGN KEY (`id_cita`) REFERENCES `citas` (`id_cita`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_notif_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE;

--
-- Constraints for table `pagos`
--
ALTER TABLE `pagos`
  ADD CONSTRAINT `fk_pagos_cita` FOREIGN KEY (`id_cita`) REFERENCES `citas` (`id_cita`) ON DELETE CASCADE;

--
-- Constraints for table `tatuadores`
--
ALTER TABLE `tatuadores`
  ADD CONSTRAINT `fk_tatuadores_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE;

--
-- Constraints for table `tatuajes_cliente`
--
ALTER TABLE `tatuajes_cliente`
  ADD CONSTRAINT `fk_tatuajes_cliente_usuario` FOREIGN KEY (`id_usuario_cliente`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE;

--
-- Constraints for table `usuario_roles`
--
ALTER TABLE `usuario_roles`
  ADD CONSTRAINT `fk_usuario_roles_rol` FOREIGN KEY (`id_rol`) REFERENCES `roles` (`id_rol`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_usuario_roles_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
