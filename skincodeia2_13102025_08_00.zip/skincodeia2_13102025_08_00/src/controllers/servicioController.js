// src/controllers/servicioController.js
const db = require('../config/db');

exports.getAll = async (req, res) => {
  try {
    const [rows] = await db.execute(`
      SELECT 
        id_servicio, 
        nombre, 
        descripcion, 
        precio, 
        activo 
      FROM servicios 
      WHERE activo = 1 
      ORDER BY precio ASC
    `);
    res.json(rows);
  } catch (err) {
    console.error('Error al cargar servicios:', err);
    res.status(500).json({ error: 'Error al cargar servicios.' });
  }
};