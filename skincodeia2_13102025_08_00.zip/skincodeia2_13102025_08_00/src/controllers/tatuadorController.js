// src/controllers/tatuadorController.js
const db = require('../config/db');

exports.getAll = async (req, res) => {
  try {
    const [rows] = await db.execute(`
      SELECT id_usuario, nombre_artistico, nombre_real, especialidad
      FROM tatuadores
      WHERE EXISTS (
        SELECT 1 FROM usuario_roles ur
        JOIN roles r ON ur.id_rol = r.id_rol
        WHERE ur.id_usuario = tatuadores.id_usuario AND r.nombre = 'tatuador'
      )
    `);
    res.json(rows);
  } catch (err) {
    console.error('Error al cargar tatuadores:', err);
    res.status(500).json({ error: 'Error al cargar tatuadores.' });
  }
};

// Obtener perfil del tatuador actual
exports.obtenerPerfil = async (req, res) => {
  const { id_usuario } = req.usuario;

  try {
    // Obtener datos del usuario
    const [usuarios] = await db.execute(
      'SELECT email, tipo FROM usuarios WHERE id_usuario = ?',
      [id_usuario]
    );

    if (usuarios.length === 0) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }

    const usuario = usuarios[0];

    // Obtener datos del perfil de tatuador
    const [tatuadores] = await db.execute(
      `SELECT nombre_artistico, nombre_real, especialidad, portfolio_url, telefono 
       FROM tatuadores WHERE id_usuario = ?`,
      [id_usuario]
    );

    if (tatuadores.length === 0) {
      // Si no tiene perfil de tatuador completado
      return res.json({
        email: usuario.email,
        tipo: usuario.tipo,
        necesitaPerfil: true
      });
    }

    const perfil = tatuadores[0];

    res.json({
      email: usuario.email,
      tipo: usuario.tipo,
      nombre_artistico: perfil.nombre_artistico,
      nombre_real: perfil.nombre_real,
      especialidad: perfil.especialidad,
      portfolio_url: perfil.portfolio_url,
      telefono: perfil.telefono,
      necesitaPerfil: false
    });
  } catch (err) {
    console.error('Error al obtener perfil de tatuador:', err);
    res.status(500).json({ error: 'No se pudo obtener el perfil' });
  }
};

// Completar o actualizar perfil de tatuador
exports.completarPerfil = async (req, res) => {
  const { id_usuario } = req.usuario;
  const { nombre_artistico, nombre_real, especialidad, portfolio_url, telefono } = req.body;

  // Validación obligatoria
  if (!nombre_artistico) {
    return res.status(400).json({ error: 'El nombre artístico es obligatorio.' });
  }

  try {
    // Verificar si ya existe un perfil de tatuador
    const [existente] = await db.execute(
      'SELECT id_usuario FROM tatuadores WHERE id_usuario = ?',
      [id_usuario]
    );

    if (existente.length > 0) {
      // Actualizar perfil existente
      await db.execute(`
        UPDATE tatuadores SET
          nombre_artistico = ?,
          nombre_real = ?,
          especialidad = ?,
          portfolio_url = ?,
          telefono = ?
        WHERE id_usuario = ?
      `, [
        nombre_artistico.trim(),
        nombre_real?.trim() || null,
        especialidad?.trim() || null,
        portfolio_url?.trim() || null,
        telefono?.trim() || null,
        id_usuario
      ]);

      res.json({ 
        message: 'Perfil de tatuador actualizado exitosamente!',
        necesitaPerfil: false 
      });
    } else {
      // Insertar nuevo perfil de tatuador
      await db.execute(`
        INSERT INTO tatuadores (
          id_usuario, nombre_artistico, nombre_real, especialidad, portfolio_url, telefono
        ) VALUES (?, ?, ?, ?, ?, ?)
      `, [
        id_usuario,
        nombre_artistico.trim(),
        nombre_real?.trim() || null,
        especialidad?.trim() || null,
        portfolio_url?.trim() || null,
        telefono?.trim() || null
      ]);

      res.json({ 
        message: 'Perfil de tatuador completado exitosamente. ¡Bienvenido/a!',
        necesitaPerfil: false 
      });
    }
  } catch (err) {
    console.error('Error al guardar perfil de tatuador:', err);
    res.status(500).json({ error: 'No se pudo guardar tu perfil. Inténtalo más tarde.' });
  }
};