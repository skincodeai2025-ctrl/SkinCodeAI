// src/controllers/perfilController.js
const db = require('../config/db');

// Obtener perfil del usuario
exports.obtenerPerfil = async (req, res) => {
  const { id_usuario } = req.usuario;

  try {
    // Obtener datos del usuario
    const [usuarios] = await db.execute(
      'SELECT email, estado FROM usuarios WHERE id_usuario = ?',
      [id_usuario]
    );

    if (usuarios.length === 0) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }

    const usuario = usuarios[0];

    // Obtener roles del usuario
    const [rolesData] = await db.execute(
      `SELECT r.nombre as rol 
       FROM usuario_roles ur 
       JOIN roles r ON ur.id_rol = r.id_rol 
       WHERE ur.id_usuario = ?`,
      [id_usuario]
    );

    const roles = rolesData.map(r => r.rol);
    const tipoUsuario = roles.length > 0 ? roles[0] : 'cliente'; // Rol principal

    // Obtener datos del perfil desde la tabla clientes
    const [clientes] = await db.execute(
      `SELECT nombre, primer_apellido, segundo_apellido, telefono, 
              direccion, fecha_naci, nickname 
       FROM clientes WHERE id_usuario = ?`,
      [id_usuario]
    );

    if (clientes.length === 0) {
      // Si no tiene perfil completado
      return res.json({
        email: usuario.email,
        tipo: tipoUsuario,
        roles: roles,
        estado: usuario.estado,
        necesitaPerfil: true
      });
    }

    const perfil = clientes[0];

    // Calcular edad
    let edad = null;
    if (perfil.fecha_naci) {
      const fechaNac = new Date(perfil.fecha_naci);
      const hoy = new Date();
      edad = hoy.getFullYear() - fechaNac.getFullYear();
      const m = hoy.getMonth() - fechaNac.getMonth();
      if (m < 0 || (m === 0 && hoy.getDate() < fechaNac.getDate())) {
        edad--;
      }
    }

    res.json({
      email: usuario.email,
      tipo: tipoUsuario,
      roles: roles,
      estado: usuario.estado,
      nombre: perfil.nombre,
      primer_apellido: perfil.primer_apellido,
      segundo_apellido: perfil.segundo_apellido,
      nombre_completo: `${perfil.nombre} ${perfil.primer_apellido || ''} ${perfil.segundo_apellido || ''}`.trim(),
      telefono: perfil.telefono,
      direccion: perfil.direccion,
      fecha_nacimiento: perfil.fecha_naci,
      edad: edad,
      nickname: perfil.nickname,
      necesitaPerfil: false
    });
  } catch (err) {
    console.error('Error al obtener perfil:', err);
    res.status(500).json({ error: 'No se pudo obtener el perfil' });
  }
};

exports.completarPerfil = async (req, res) => {
  const { id_usuario } = req.usuario; // viene del middleware auth
  
  // Aceptar ambos formatos de campos (fecha_naci y fecha_nacimiento)
  const { 
    nombre, 
    fecha_naci, 
    fecha_nacimiento,
    primer_apellido, 
    segundo_apellido, 
    telefono, 
    direccion, 
    ciudad,
    pais,
    nickname 
  } = req.body;

  // Usar el campo que venga (fecha_naci o fecha_nacimiento)
  const fechaNaci = fecha_naci || fecha_nacimiento;

  // Validación obligatoria
  if (!nombre || !fechaNaci) {
    return res.status(400).json({ error: 'Nombre y fecha de nacimiento son obligatorios.' });
  }

  // Validar formato de fecha
  const fechaNacimiento = new Date(fechaNaci);
  if (isNaN(fechaNacimiento.getTime())) {
    return res.status(400).json({ error: 'Fecha de nacimiento inválida.' });
  }

  // Calcular edad
  const hoy = new Date();
  let edad = hoy.getFullYear() - fechaNacimiento.getFullYear();
  const mesActual = hoy.getMonth();
  const diaActual = hoy.getDate();
  const mesNac = fechaNacimiento.getMonth();
  const diaNac = fechaNacimiento.getDate();

  if (mesActual < mesNac || (mesActual === mesNac && diaActual < diaNac)) {
    edad--;
  }

  // Validar mayoría de edad
  if (edad < 18) {
    return res.status(403).json({ 
      error: 'Lo sentimos, debes ser mayor de 18 años para usar nuestros servicios.' 
    });
  }

  try {
    // Verificar si ya existe un perfil
    const [existente] = await db.execute(
      'SELECT id_cliente FROM clientes WHERE id_usuario = ?',
      [id_usuario]
    );

    if (existente.length > 0) {
      // Actualizar perfil existente
      await db.execute(`
        UPDATE clientes SET
          nombre = ?,
          primer_apellido = ?,
          segundo_apellido = ?,
          telefono = ?,
          direccion = ?,
          fecha_naci = ?,
          nickname = ?
        WHERE id_usuario = ?
      `, [
        nombre.trim(),
        primer_apellido?.trim() || '',
        segundo_apellido?.trim() || '',
        telefono?.trim() || '',
        direccion?.trim() || '',
        fechaNaci,
        nickname?.trim() || null,
        id_usuario
      ]);

      res.json({ 
        message: 'Perfil actualizado exitosamente!',
        necesitaPerfil: false 
      });
    } else {
      // Insertar nuevo perfil
      await db.execute(`
        INSERT INTO clientes (
          id_usuario, nombre, primer_apellido, segundo_apellido,
          telefono, direccion, fecha_naci, nickname
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        id_usuario,
        nombre.trim(),
        primer_apellido?.trim() || '',
        segundo_apellido?.trim() || '',
        telefono?.trim() || '',
        direccion?.trim() || '',
        fechaNaci,
        nickname?.trim() || null
      ]);

      res.json({ 
        message: 'Perfil completado exitosamente. Bienvenido/a!',
        necesitaPerfil: false 
      });
    }
  } catch (err) {
    console.error('Error al guardar perfil:', err);
    res.status(500).json({ error: 'No se pudo guardar tu perfil. Inténtalo más tarde.' });
  }
};