// src/controllers/pagoController.js
const db = require('../config/db');
const Citas = require('../models/Citas');
const Pagos = require('../models/Pagos');

// Registrar pago sobre una cita utilizando los campos de citas (pago_estado, pago_monto, pago_fecha)
// Nota: el "metodo" se conserva opcionalmente en notas_internas como etiqueta.
exports.registrarPago = async (req, res) => {
  try {
    const { id_cita, monto, metodo = 'efectivo', fecha, referencia } = req.body || {};
    if (!id_cita || !monto) return res.status(400).json({ error: 'id_cita y monto son requeridos' });
    // Obtener cita para preservar notas_internas
    const cita = await Citas.getById(id_cita);
    if (!cita) return res.status(404).json({ error: 'Cita no encontrada' });

    let notas_internas = cita.notas_internas || '';
    const tag = `[pago_metodo:${metodo}]`;
    const tagRef = referencia ? `[pago_ref:${referencia}]` : '';
    if (!notas_internas.includes(tag)) notas_internas = `${tag} ${notas_internas}`.trim();
    if (tagRef && !notas_internas.includes(tagRef)) notas_internas = `${tagRef} ${notas_internas}`.trim();
    const when = fecha || new Date().toISOString().slice(0, 19).replace('T', ' ');

    // Intentar guardar en tabla pagos primero
    try {
      await Pagos.create({ id_cita, monto, metodo, fecha: when, referencia });
    } catch (err) {
      // Si la tabla no existe, ignora y usa campos de citas como fallback
      if (!(err && (err.code === 'ER_NO_SUCH_TABLE' || err.code === 'ER_NO_REFERENCED_ROW'))) {
        console.warn('Pagos.create fallback -> citas:', err?.code || err);
      }
    }

    // Mantener sincronizado el estado de la cita
    await Citas.realizar(id_cita, {
      pago_monto: monto,
      pago_estado: 'pagado',
      pago_fecha: when,
    });
    try { await Citas.update(id_cita, { notas_internas }); } catch {}

    res.json({ message: 'Pago registrado', id_cita, metodo, monto, fecha: when, referencia });
  } catch (err) {
    console.error('Error al registrar pago:', err);
    res.status(500).json({ error: 'No se pudo registrar el pago.' });
  }
};

// Reporte de pagos agregados desde tabla citas
// GET /api/pagos/report?desde=YYYY-MM-DD&hasta=YYYY-MM-DD&granularity=day|week|month&id_usuario_tatuador=ID
exports.reporte = async (req, res) => {
  try {
    const { desde, hasta, granularity = 'day', id_usuario_tatuador } = req.query;
    // Intentar reporte desde tabla pagos; fallback a campos de citas
    try {
      const rows = await Pagos.report({ desde, hasta, granularity, id_usuario_tatuador });
      return res.json(rows);
    } catch (err) {
      console.warn('Pagos.report fallback -> citas:', err?.code || err);
      const params = [];
      let where = "pago_estado = 'pagado'";
      if (desde) { where += ' AND pago_fecha >= ?'; params.push(desde + (desde.length === 10 ? ' 00:00:00' : '')); }
      if (hasta) { where += ' AND pago_fecha <= ?'; params.push(hasta + (hasta.length === 10 ? ' 23:59:59' : '')); }
      if (id_usuario_tatuador) { where += ' AND id_usuario_tatuador = ?'; params.push(id_usuario_tatuador); }
      let periodExpr = 'DATE(pago_fecha)';
      if (granularity === 'week') periodExpr = 'YEARWEEK(pago_fecha, 3)';
      if (granularity === 'month') periodExpr = 'DATE_FORMAT(pago_fecha, "%Y-%m")';
      const [rows] = await db.execute(
        `SELECT ${periodExpr} AS periodo, COUNT(*) AS pagos, SUM(pago_monto) AS total
         FROM citas
         WHERE ${where}
         GROUP BY periodo
         ORDER BY periodo ASC`,
        params
      );
      return res.json(rows);
    }
  } catch (err) {
    console.error('Error en reporte de pagos:', err);
    res.status(500).json({ error: 'Error al generar reporte.' });
  }
};
