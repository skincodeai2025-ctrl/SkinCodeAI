// src/controllers/tatuajeController.js
const TatuajeCliente = require('../models/TatuajeCliente');

exports.crearTatuaje = async (req, res) => {
  try {
    const { id_usuario } = req.usuario; // del JWT
    const id = await TatuajeCliente.create(id_usuario, req.body);
    res.status(201).json({ id_tatuaje_cliente: id, message: 'Tatuaje registrado exitosamente.' });
  } catch (err) {
    console.error('Error al registrar tatuaje:', err);
    res.status(500).json({ error: 'No se pudo guardar el tatuaje.' });
  }
};

exports.getMisTatuajes = async (req, res) => {
  try {
    const { id_usuario } = req.usuario;
    const tatuajes = await TatuajeCliente.getByCliente(id_usuario);
    res.json(tatuajes);
  } catch (err) {
    console.error('Error al cargar tatuajes:', err);
    res.status(500).json({ error: 'Error al cargar tus tatuajes.' });
  }
};