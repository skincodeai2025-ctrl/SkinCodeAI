const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/authController');

router.post('/register', ctrl.registerBasic);
router.post('/login', ctrl.login);
router.post('/google', ctrl.googleLogin);
router.get('/config', ctrl.authConfig);

module.exports = router;