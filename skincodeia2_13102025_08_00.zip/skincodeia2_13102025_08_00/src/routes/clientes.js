const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth'); // middleware JWT
const ctrl = require('../controllers/clienteController');

router.get('/', auth, ctrl.getAllClientes);
router.get('/:id', auth, ctrl.getClienteById);
router.post('/', auth, ctrl.createCliente);
router.put('/:id', auth, ctrl.updateCliente);
router.delete('/:id', auth, ctrl.deleteCliente);

module.exports = router;