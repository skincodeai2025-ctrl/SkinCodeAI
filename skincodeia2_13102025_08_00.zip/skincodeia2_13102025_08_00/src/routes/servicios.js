// src/routes/servicios.js
const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const ctrl = require('../controllers/servicioController');

router.get('/', auth, ctrl.getAll);

module.exports = router;