// src/routes/pagos.js
const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const ctrl = require('../controllers/pagoController');

// Registrar un pago (efectivo, electrónico, bitcoin via metodo)
router.post('/', auth, ctrl.registrarPago);

// Reportes agregados
router.get('/report', auth, ctrl.reporte);

module.exports = router;
