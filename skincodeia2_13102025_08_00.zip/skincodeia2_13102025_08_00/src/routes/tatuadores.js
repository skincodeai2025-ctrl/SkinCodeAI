// src/routes/tatuadores.js
const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const ctrl = require('../controllers/tatuadorController');

router.get('/', auth, ctrl.getAll);
router.get('/perfil', auth, ctrl.obtenerPerfil);
router.post('/perfil/completar', auth, ctrl.completarPerfil);

module.exports = router;