const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth'); // ✅ Ruta correcta al middleware de backend
const ctrl = require('../controllers/perfilController');

router.get('/', auth, ctrl.obtenerPerfil);
router.post('/completar', auth, ctrl.completarPerfil);

module.exports = router;