const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const ctrl = require('../controllers/citaController');

router.post('/', auth, ctrl.crearSolicitud);
router.get('/mias', auth, ctrl.getMisCitas);
// CRUD y transiciones
router.get('/', auth, ctrl.list);
router.get('/export.csv', auth, ctrl.exportCsv);
router.get('/:id', auth, ctrl.getById);
router.put('/:id', auth, ctrl.update);
router.put('/:id/programar', auth, ctrl.programar);
router.put('/:id/confirmar', auth, ctrl.confirmar);
router.put('/:id/cancelar', auth, ctrl.cancelar);
router.put('/:id/realizar', auth, ctrl.realizar);

module.exports = router;