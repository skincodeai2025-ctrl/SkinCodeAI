// src/routes/financieros.js
const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const ctrl = require('../controllers/financieroController');

// Middleware para verificar que el usuario tenga permisos de administrador/soporte
const verificarPermisosAdmin = (req, res, next) => {
  if (req.usuario.rol !== 'soporte') {
    return res.status(403).json({
      error: 'Acceso denegado. Se requieren permisos de administrador.'
    });
  }
  next();
};

// Aplicar middleware de autenticación y permisos a todas las rutas
router.use(auth);
router.use(verificarPermisosAdmin);

// Dashboard financiero completo
router.get('/dashboard', ctrl.getDashboardFinanciero);

// Reportes específicos
router.get('/ingresos/periodo', ctrl.getIngresosPorPeriodo);
router.get('/ingresos/tatuador', ctrl.getIngresosPorTatuador);
router.get('/servicios/populares', ctrl.getServiciosMasPopulares);
router.get('/ganancias-netas', ctrl.getGananciasNetas);
router.get('/metricas-generales', ctrl.getMetricasGenerales);
router.get('/tendencias/citas', ctrl.getTendenciasCitas);
router.get('/pagos/metodo', ctrl.getPagosPorMetodo);
router.get('/citas/estado', ctrl.getCitasPorEstado);

// Exportar reportes
router.get('/exportar/csv', ctrl.exportarReporteCSV);

module.exports = router;
