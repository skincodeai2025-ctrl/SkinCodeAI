// src/routes/notificaciones.js
const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const ctrl = require('../controllers/notificacionController');

// Obtener mis notificaciones
router.get('/', auth, ctrl.getMisNotificaciones);

// Contar no leídas
router.get('/count', auth, ctrl.contarNoLeidas);

// Marcar como leída
router.put('/:id/leer', auth, ctrl.marcarLeida);

// Marcar todas como leídas
router.put('/leer-todas', auth, ctrl.marcarTodasLeidas);

// Eliminar notificación
router.delete('/:id', auth, ctrl.eliminar);

module.exports = router;
