const db = require('../config/db');
const bcrypt = require('bcrypt');

class Usuario {
  static async findByEmail(email) {
    const [rows] = await db.execute(`
      SELECT u.id_usuario, u.email, u.estado, c.hash_clave, r.nombre AS rol
      FROM usuarios u
      LEFT JOIN credenciales c ON u.id_usuario = c.id_usuario
      LEFT JOIN usuario_roles ur ON u.id_usuario = ur.id_usuario
      LEFT JOIN roles r ON ur.id_rol = r.id_rol
      WHERE u.email = ?
    `, [email]);
    return rows[0];
  }

  static async create(email, clave, rol = 'cliente') {
    const conn = await db.getConnection();
    try {
      await conn.beginTransaction();

      const [user] = await conn.execute('INSERT INTO usuarios (email) VALUES (?)', [email]);
      const userId = user.insertId;

      const salt = await bcrypt.genSalt(10);
      const hash = await bcrypt.hash(clave, salt);
      await conn.execute('INSERT INTO credenciales (id_usuario, hash_clave, salt) VALUES (?, ?, ?)', [userId, hash, salt]);

      const [rolRow] = await conn.execute('SELECT id_rol FROM roles WHERE nombre = ?', [rol]);
      if (!rolRow.length) throw new Error('Rol no válido');
      await conn.execute('INSERT INTO usuario_roles (id_usuario, id_rol) VALUES (?, ?)', [userId, rolRow[0].id_rol]);

      await conn.commit();
      return { id_usuario: userId };
    } catch (err) {
      await conn.rollback();
      throw err;
    } finally {
      conn.release();
    }
  }
}

module.exports = Usuario;