const db = require('../config/db');

class Citas {
  static async createSolicitud(id_usuario_cliente, { id_servicio = null, notas_cliente = null, notas_internas = null, url_referencia = null }) {
    try {
      const [result] = await db.execute(`
        INSERT INTO citas (
          id_usuario_cliente, id_servicio, notas_cliente, notas_internas, url_referencia, estado
        ) VALUES (?, ?, ?, ?, ?, 'solicitud')
      `, [id_usuario_cliente, id_servicio, notas_cliente, notas_internas, url_referencia]);
      return result.insertId;
    } catch (err) {
      if (err && err.code === 'ER_BAD_FIELD_ERROR') {
        const [result2] = await db.execute(`
          INSERT INTO citas (
            id_cliente, id_servicio, notas_cliente, notas_internas, url_referencia, estado
          ) VALUES (?, ?, ?, ?, ?, 'solicitud')
        `, [id_usuario_cliente, id_servicio, notas_cliente, notas_internas, url_referencia]);
        return result2.insertId;
      }
      throw err;
    }
  }

  static async getById(id_cita) {
    const [rows] = await db.execute(
      `SELECT 
         ci.*, 
         CONCAT(COALESCE(cl.nombre,''), ' ', COALESCE(cl.primer_apellido,'')) AS cliente_nombre,
         ta.nombre_artistico AS tatuador_nombre,
         sv.nombre AS servicio_nombre
       FROM citas ci
       LEFT JOIN clientes cl ON cl.id_usuario = ci.id_usuario_cliente
       LEFT JOIN tatuadores ta ON ta.id_usuario = ci.id_usuario_tatuador
       LEFT JOIN servicios sv ON sv.id_servicio = ci.id_servicio
       WHERE ci.id_cita = ?`,
      [id_cita]
    );
    return rows[0] || null;
  }

  static async list({ id_usuario_cliente = null, id_usuario_tatuador = null, id_servicio = null, estado = null, fecha_desde = null, fecha_hasta = null, limit = null, offset = null }) {
    const where = [];
    const params = [];
    if (id_usuario_cliente) { where.push('ci.id_usuario_cliente = ?'); params.push(id_usuario_cliente); }
    if (id_usuario_tatuador) { where.push('ci.id_usuario_tatuador = ?'); params.push(id_usuario_tatuador); }
    if (estado) { where.push('ci.estado = ?'); params.push(estado); }
    if (id_servicio) { where.push('ci.id_servicio = ?'); params.push(id_servicio); }
    if (fecha_desde) { where.push('(ci.fecha_hora_inicio IS NULL OR ci.fecha_hora_inicio >= ?)'); params.push(fecha_desde); }
    if (fecha_hasta) { where.push('(ci.fecha_hora_fin IS NULL OR ci.fecha_hora_fin <= ?)'); params.push(fecha_hasta); }
    const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
    let sql = 
      `SELECT 
         ci.*, 
         CONCAT(COALESCE(cl.nombre,''), ' ', COALESCE(cl.primer_apellido,'')) AS cliente_nombre,
         ta.nombre_artistico AS tatuador_nombre,
         sv.nombre AS servicio_nombre
       FROM citas ci
       LEFT JOIN clientes cl ON cl.id_usuario = ci.id_usuario_cliente
       LEFT JOIN tatuadores ta ON ta.id_usuario = ci.id_usuario_tatuador
       LEFT JOIN servicios sv ON sv.id_servicio = ci.id_servicio
       ${whereSql}
       ORDER BY COALESCE(ci.fecha_hora_inicio, ci.creado_en) DESC`;
    if (limit !== null) {
      sql += ' LIMIT ? OFFSET ?';
      params.push(Number(limit), Number(offset || 0));
    }
    try {
      const [rows] = await db.execute(sql, params);
      return rows;
    } catch (err) {
      if (err && err.code === 'ER_BAD_FIELD_ERROR') {
        // Reintentar usando columnas legadas id_cliente / id_tatuador
        const where2 = [];
        const params2 = [];
        if (id_usuario_cliente) { where2.push('ci.id_cliente = ?'); params2.push(id_usuario_cliente); }
        if (id_usuario_tatuador) { where2.push('ci.id_tatuador = ?'); params2.push(id_usuario_tatuador); }
        if (estado) { where2.push('ci.estado = ?'); params2.push(estado); }
        if (id_servicio) { where2.push('ci.id_servicio = ?'); params2.push(id_servicio); }
        if (fecha_desde) { where2.push('(ci.fecha_hora_inicio IS NULL OR ci.fecha_hora_inicio >= ?)'); params2.push(fecha_desde); }
        if (fecha_hasta) { where2.push('(ci.fecha_hora_fin IS NULL OR ci.fecha_hora_fin <= ?)'); params2.push(fecha_hasta); }
        const whereSql2 = where2.length ? `WHERE ${where2.join(' AND ')}` : '';
        let sql2 = 
          `SELECT 
             ci.*, 
             CONCAT(COALESCE(cl.nombre,''), ' ', COALESCE(cl.primer_apellido,'')) AS cliente_nombre,
             ta.nombre_artistico AS tatuador_nombre,
             sv.nombre AS servicio_nombre
           FROM citas ci
           LEFT JOIN clientes cl ON cl.id_usuario = ci.id_cliente
           LEFT JOIN tatuadores ta ON ta.id_usuario = ci.id_tatuador
           LEFT JOIN servicios sv ON sv.id_servicio = ci.id_servicio
           ${whereSql2}
           ORDER BY COALESCE(ci.fecha_hora_inicio, ci.creado_en) DESC`;
        if (limit !== null) {
          sql2 += ' LIMIT ? OFFSET ?';
          params2.push(Number(limit), Number(offset || 0));
        }
        const [rows2] = await db.execute(sql2, params2);
        return rows2;
      }
      throw err;
    }
  }

  static async programar(id_cita, { id_usuario_tatuador, fecha_hora_inicio, fecha_hora_fin, precio = null, notas_internas = null }) {
    // Validaciones básicas
    if (!id_usuario_tatuador || !fecha_hora_inicio || !fecha_hora_fin) {
      const err = new Error('Campos requeridos faltantes');
      err.code = 'VALIDATION_ERROR';
      throw err;
    }

    // Validar solapamiento de horarios para el mismo tatuador cuando la cita está programada/confirmada
    let overlaps;
    try {
      [overlaps] = await db.execute(`
        SELECT 1 FROM citas
        WHERE id_usuario_tatuador = ?
          AND id_cita <> ?
          AND estado IN ('programada','confirmada')
          AND fecha_hora_inicio < ?
          AND fecha_hora_fin > ?
        LIMIT 1
      `, [id_usuario_tatuador, id_cita, fecha_hora_fin, fecha_hora_inicio]);
    } catch (err) {
      if (err && err.code === 'ER_BAD_FIELD_ERROR') {
        const r = await db.execute(`
          SELECT 1 FROM citas
          WHERE id_tatuador = ?
            AND id_cita <> ?
            AND estado IN ('programada','confirmada')
            AND fecha_hora_inicio < ?
            AND fecha_hora_fin > ?
          LIMIT 1
        `, [id_usuario_tatuador, id_cita, fecha_hora_fin, fecha_hora_inicio]);
        overlaps = r[0];
      } else { throw err; }
    }

    if (overlaps.length > 0) {
      const err = new Error('Horario no disponible para el tatuador');
      err.code = 'OVERLAP';
      throw err;
    }

    try {
      await db.execute(`
        UPDATE citas SET
          id_usuario_tatuador = ?,
          fecha_hora_inicio = ?,
          fecha_hora_fin = ?,
          precio = ?,
          notas_internas = COALESCE(?, notas_internas),
          estado = 'programada'
        WHERE id_cita = ?
      `, [id_usuario_tatuador, fecha_hora_inicio, fecha_hora_fin, precio, notas_internas, id_cita]);
    } catch (err) {
      if (err && err.code === 'ER_BAD_FIELD_ERROR') {
        await db.execute(`
          UPDATE citas SET
            id_tatuador = ?,
            fecha_hora_inicio = ?,
            fecha_hora_fin = ?,
            precio = ?,
            notas_internas = COALESCE(?, notas_internas),
            estado = 'programada'
          WHERE id_cita = ?
        `, [id_usuario_tatuador, fecha_hora_inicio, fecha_hora_fin, precio, notas_internas, id_cita]);
      } else { throw err; }
    }
  }

  static async confirmar(id_cita) {
    await db.execute(`UPDATE citas SET estado = 'confirmada' WHERE id_cita = ?`, [id_cita]);
  }

  static async cancelar(id_cita, { notas_internas = null } = {}) {
    await db.execute(`UPDATE citas SET estado = 'cancelada', notas_internas = COALESCE(?, notas_internas) WHERE id_cita = ?`, [notas_internas, id_cita]);
  }

  static async realizar(id_cita, { pago_monto = null, pago_estado = 'pagado', pago_fecha = null } = {}) {
    await db.execute(`
      UPDATE citas SET
        estado = 'realizada',
        pago_estado = ?,
        pago_monto = ?,
        pago_fecha = ?
      WHERE id_cita = ?
    `, [pago_estado, pago_monto, pago_fecha, id_cita]);
  }

  static async update(id_cita, data) {
    const {
      id_usuario_tatuador = null,
      id_servicio = null,
      fecha_hora_inicio = null,
      fecha_hora_fin = null,
      precio = null,
      notas_cliente = null,
      notas_internas = null,
      url_referencia = null,
      estado = null
    } = data;

    try {
      await db.execute(`
        UPDATE citas SET
          id_usuario_tatuador = COALESCE(?, id_usuario_tatuador),
          id_servicio = COALESCE(?, id_servicio),
          fecha_hora_inicio = COALESCE(?, fecha_hora_inicio),
          fecha_hora_fin = COALESCE(?, fecha_hora_fin),
          precio = COALESCE(?, precio),
          notas_cliente = COALESCE(?, notas_cliente),
          notas_internas = COALESCE(?, notas_internas),
          url_referencia = COALESCE(?, url_referencia),
          estado = COALESCE(?, estado)
        WHERE id_cita = ?
      `, [id_usuario_tatuador, id_servicio, fecha_hora_inicio, fecha_hora_fin, precio, notas_cliente, notas_internas, url_referencia, estado, id_cita]);
    } catch (err) {
      if (err && err.code === 'ER_BAD_FIELD_ERROR') {
        await db.execute(`
          UPDATE citas SET
            id_tatuador = COALESCE(?, id_tatuador),
            id_servicio = COALESCE(?, id_servicio),
            fecha_hora_inicio = COALESCE(?, fecha_hora_inicio),
            fecha_hora_fin = COALESCE(?, fecha_hora_fin),
            precio = COALESCE(?, precio),
            notas_cliente = COALESCE(?, notas_cliente),
            notas_internas = COALESCE(?, notas_internas),
            url_referencia = COALESCE(?, url_referencia),
            estado = COALESCE(?, estado)
          WHERE id_cita = ?
        `, [id_usuario_tatuador, id_servicio, fecha_hora_inicio, fecha_hora_fin, precio, notas_cliente, notas_internas, url_referencia, estado, id_cita]);
      } else { throw err; }
    }
  }
}

module.exports = Citas;
