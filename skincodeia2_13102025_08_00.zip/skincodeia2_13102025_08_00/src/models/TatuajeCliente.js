// src/models/TatuajeCliente.js
const db = require('../config/db');

class TatuajeCliente {
  static async create(id_cliente, data) {
    const {
      ubicacion_cuerpo,
      descripcion,
      fecha_realizacion,
      nombre_tatuador,
      url_imagen,
      categoria = 'ninguno'
    } = data;

    // Intentar con la columna estándar 'id_usuario_cliente', fallback a 'id_cliente'
    try {
      const [result] = await db.execute(`
        INSERT INTO tatuajes_cliente (
          id_usuario_cliente, ubicacion_cuerpo, descripcion, fecha_realizacion,
          nombre_tatuador, url_imagen, categoria
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
      `, [
        id_cliente,
        ubicacion_cuerpo || null,
        descripcion || null,
        fecha_realizacion || null,
        nombre_tatuador || null,
        url_imagen || null,
        categoria
      ]);
      return result.insertId;
    } catch (err) {
      if (err && err.code === 'ER_BAD_FIELD_ERROR') {
        const [result2] = await db.execute(`
          INSERT INTO tatuajes_cliente (
            id_cliente, ubicacion_cuerpo, descripcion, fecha_realizacion,
            nombre_tatuador, url_imagen, categoria
          ) VALUES (?, ?, ?, ?, ?, ?, ?)
        `, [
          id_cliente,
          ubicacion_cuerpo || null,
          descripcion || null,
          fecha_realizacion || null,
          nombre_tatuador || null,
          url_imagen || null,
          categoria
        ]);
        return result2.insertId;
      }
      throw err;
    }
  }

  static async getByCliente(id_cliente) {
    try {
      const [rows] = await db.execute(
        'SELECT * FROM tatuajes_cliente WHERE id_usuario_cliente = ? ORDER BY creado_en DESC',
        [id_cliente]
      );
      return rows;
    } catch (err) {
      if (err && err.code === 'ER_BAD_FIELD_ERROR') {
        const [rows2] = await db.execute(
          'SELECT * FROM tatuajes_cliente WHERE id_cliente = ? ORDER BY creado_en DESC',
          [id_cliente]
        );
        return rows2;
      }
      throw err;
    }
  }
}

module.exports = TatuajeCliente;