const db = require('../config/db');

class Tatuadores {
  static async getAll() {
    const [rows] = await db.execute(`
      SELECT t.id_usuario, t.nombre_artistico, t.nombre_real, t.especialidad, t.portfolio_url, t.telefono
      FROM tatuadores t
    `);
    return rows;
  }

  static async getById(id_usuario) {
    const [rows] = await db.execute(`
      SELECT t.id_usuario, t.nombre_artistico, t.nombre_real, t.especialidad, t.portfolio_url, t.telefono
      FROM tatuadores t
      WHERE t.id_usuario = ?
    `, [id_usuario]);
    return rows[0] || null;
  }

  static async create(id_usuario, data) {
    const { nombre_artistico, nombre_real = null, especialidad = null, portfolio_url = null, telefono = null } = data;
    await db.execute(`
      INSERT INTO tatuadores (id_usuario, nombre_artistico, nombre_real, especialidad, portfolio_url, telefono)
      VALUES (?, ?, ?, ?, ?, ?)
    `, [id_usuario, nombre_artistico, nombre_real, especialidad, portfolio_url, telefono]);
  }

  static async update(id_usuario, data) {
    const { nombre_artistico, nombre_real, especialidad, portfolio_url, telefono } = data;
    await db.execute(`
      UPDATE tatuadores SET
        nombre_artistico = COALESCE(?, nombre_artistico),
        nombre_real = COALESCE(?, nombre_real),
        especialidad = COALESCE(?, especialidad),
        portfolio_url = COALESCE(?, portfolio_url),
        telefono = COALESCE(?, telefono)
      WHERE id_usuario = ?
    `, [nombre_artistico, nombre_real, especialidad, portfolio_url, telefono, id_usuario]);
  }

  static async delete(id_usuario) {
    // Hard delete ya que no hay campo activo
    await db.execute('DELETE FROM tatuadores WHERE id_usuario = ?', [id_usuario]);
  }
}

module.exports = Tatuadores;
