// src/models/Pagos.js
const db = require('../config/db');

// Tabla esperada:
// pagos(id_pago PK, id_cita FK, monto DECIMAL, metodo ENUM('efectivo','electronico','bitcoin'), referencia VARCHAR, fecha DATETIME)
// Si no existe, el controlador hará fallback a la tabla citas.

class Pagos {
  static async create({ id_cita, monto, metodo = 'efectivo', referencia = null, fecha = null, id_usuario_tatuador = null }) {
    const when = fecha || new Date().toISOString().slice(0, 19).replace('T', ' ');
    const [r] = await db.execute(
      `INSERT INTO pagos (id_cita, monto, metodo, referencia, fecha)
       VALUES (?, ?, ?, ?, ?)`,
      [id_cita, monto, metodo, referencia, when]
    );
    return r.insertId;
  }

  static async list({ desde, hasta, id_usuario_tatuador } = {}) {
    const where = [];
    const params = [];
    if (desde) { where.push('p.fecha >= ?'); params.push(desde); }
    if (hasta) { where.push('p.fecha <= ?'); params.push(hasta); }
    if (id_usuario_tatuador) { where.push('c.id_usuario_tatuador = ?'); params.push(id_usuario_tatuador); }
    const whereSql = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const [rows] = await db.execute(
      `SELECT p.*, c.id_usuario_tatuador
       FROM pagos p
       LEFT JOIN citas c ON c.id_cita = p.id_cita
       ${whereSql}
       ORDER BY p.fecha DESC`,
      params
    );
    return rows;
  }

  static async report({ desde, hasta, granularity = 'day', id_usuario_tatuador } = {}) {
    const where = [];
    const params = [];
    if (desde) { where.push('p.fecha >= ?'); params.push(desde); }
    if (hasta) { where.push('p.fecha <= ?'); params.push(hasta); }
    if (id_usuario_tatuador) { where.push('c.id_usuario_tatuador = ?'); params.push(id_usuario_tatuador); }
    const whereSql = where.length ? 'WHERE ' + where.join(' AND ') : '';

    let periodExpr = 'DATE(p.fecha)';
    if (granularity === 'week') periodExpr = 'YEARWEEK(p.fecha, 3)';
    if (granularity === 'month') periodExpr = 'DATE_FORMAT(p.fecha, "%Y-%m")';

    const [rows] = await db.execute(
      `SELECT ${periodExpr} AS periodo, COUNT(*) AS pagos, SUM(p.monto) AS total
       FROM pagos p
       LEFT JOIN citas c ON c.id_cita = p.id_cita
       ${whereSql}
       GROUP BY periodo
       ORDER BY periodo ASC`,
      params
    );
    return rows;
  }
}

module.exports = Pagos;
