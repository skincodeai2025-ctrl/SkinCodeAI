// src/models/Notificaciones.js
const db = require('../config/db');

class Notificaciones {
  /**
   * Crear una notificación
   * @param {Object} data - { id_usuario, tipo, titulo, mensaje, id_cita, leida }
   */
  static async create(data) {
    const { id_usuario, tipo = 'info', titulo, mensaje, id_cita = null, leida = false } = data;
    
    try {
      const [result] = await db.execute(`
        INSERT INTO notificaciones (
          id_usuario, tipo, titulo, mensaje, id_cita, leida, fecha_creacion
        ) VALUES (?, ?, ?, ?, ?, ?, NOW())
      `, [id_usuario, tipo, titulo, mensaje, id_cita, leida ? 1 : 0]);
      
      return result.insertId;
    } catch (err) {
      // Si la tabla no existe, crear tabla automáticamente
      if (err.code === 'ER_NO_SUCH_TABLE') {
        await this.createTable();
        return await this.create(data);
      }
      throw err;
    }
  }

  /**
   * Obtener notificaciones de un usuario
   * @param {number} id_usuario 
   * @param {Object} options - { limit, offset, solo_no_leidas }
   */
  static async getByUsuario(id_usuario, options = {}) {
    const { limit = 20, offset = 0, solo_no_leidas = false } = options;
    
    try {
      let query = `
        SELECT 
          n.*,
          c.estado as cita_estado,
          c.fecha_hora_inicio as cita_fecha
        FROM notificaciones n
        LEFT JOIN citas c ON c.id_cita = n.id_cita
        WHERE n.id_usuario = ?
      `;
      
      const params = [id_usuario];
      
      if (solo_no_leidas) {
        query += ` AND n.leida = 0`;
      }
      
      query += ` ORDER BY n.fecha_creacion DESC LIMIT ? OFFSET ?`;
      params.push(limit, offset);
      
      const [rows] = await db.execute(query, params);
      return rows;
    } catch (err) {
      if (err.code === 'ER_NO_SUCH_TABLE') {
        await this.createTable();
        return [];
      }
      throw err;
    }
  }

  /**
   * Contar notificaciones no leídas
   */
  static async countNoLeidas(id_usuario) {
    try {
      const [rows] = await db.execute(`
        SELECT COUNT(*) as total
        FROM notificaciones
        WHERE id_usuario = ? AND leida = 0
      `, [id_usuario]);
      
      return rows[0]?.total || 0;
    } catch (err) {
      if (err.code === 'ER_NO_SUCH_TABLE') {
        await this.createTable();
        return 0;
      }
      throw err;
    }
  }

  /**
   * Marcar notificación como leída
   */
  static async marcarLeida(id_notificacion, id_usuario) {
    const [result] = await db.execute(`
      UPDATE notificaciones
      SET leida = 1, fecha_lectura = NOW()
      WHERE id_notificacion = ? AND id_usuario = ?
    `, [id_notificacion, id_usuario]);
    
    return result.affectedRows > 0;
  }

  /**
   * Marcar todas como leídas
   */
  static async marcarTodasLeidas(id_usuario) {
    const [result] = await db.execute(`
      UPDATE notificaciones
      SET leida = 1, fecha_lectura = NOW()
      WHERE id_usuario = ? AND leida = 0
    `, [id_usuario]);
    
    return result.affectedRows;
  }

  /**
   * Eliminar notificación
   */
  static async delete(id_notificacion, id_usuario) {
    const [result] = await db.execute(`
      DELETE FROM notificaciones
      WHERE id_notificacion = ? AND id_usuario = ?
    `, [id_notificacion, id_usuario]);
    
    return result.affectedRows > 0;
  }

  /**
   * Crear tabla de notificaciones si no existe
   */
  static async createTable() {
    await db.execute(`
      CREATE TABLE IF NOT EXISTS notificaciones (
        id_notificacion INT AUTO_INCREMENT PRIMARY KEY,
        id_usuario INT NOT NULL,
        tipo ENUM('info', 'success', 'warning', 'error', 'cita') DEFAULT 'info',
        titulo VARCHAR(255) NOT NULL,
        mensaje TEXT,
        id_cita INT NULL,
        leida BOOLEAN DEFAULT FALSE,
        fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
        fecha_lectura DATETIME NULL,
        INDEX idx_usuario (id_usuario),
        INDEX idx_leida (leida),
        INDEX idx_fecha (fecha_creacion),
        FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE,
        FOREIGN KEY (id_cita) REFERENCES citas(id_cita) ON DELETE SET NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);
  }

  /**
   * Crear notificación de cambio de estado de cita
   */
  static async notificarCambioCita(id_cita, estado_anterior, estado_nuevo) {
    try {
      // Obtener información de la cita
      const [citas] = await db.execute(`
        SELECT 
          c.*,
          cli.nombre as cliente_nombre,
          tat.nombre as tatuador_nombre
        FROM citas c
        LEFT JOIN clientes cli ON cli.id_usuario = c.id_usuario_cliente
        LEFT JOIN tatuadores tat ON tat.id_usuario = c.id_usuario_tatuador
        WHERE c.id_cita = ?
      `, [id_cita]);

      if (!citas || citas.length === 0) return;
      const cita = citas[0];

      // Mensajes según el cambio de estado
      const mensajes = {
        solicitud: {
          titulo: '📋 Nueva solicitud de cita',
          mensaje: 'Tu solicitud de cita ha sido registrada. Te notificaremos cuando sea programada.'
        },
        programada: {
          titulo: '📅 Cita programada',
          mensaje: `Tu cita ha sido programada para el ${cita.fecha_hora_inicio ? new Date(cita.fecha_hora_inicio).toLocaleString('es-ES') : 'fecha por confirmar'}.`
        },
        confirmada: {
          titulo: '✅ Cita confirmada',
          mensaje: `Tu cita ha sido confirmada. Te esperamos el ${cita.fecha_hora_inicio ? new Date(cita.fecha_hora_inicio).toLocaleString('es-ES') : 'fecha programada'}.`
        },
        realizada: {
          titulo: '🎉 Cita completada',
          mensaje: 'Tu cita ha sido completada exitosamente. ¡Gracias por confiar en nosotros!'
        },
        cancelada: {
          titulo: '❌ Cita cancelada',
          mensaje: 'Tu cita ha sido cancelada. Puedes agendar una nueva cuando lo desees.'
        }
      };

      const notif = mensajes[estado_nuevo] || {
        titulo: 'Actualización de cita',
        mensaje: `El estado de tu cita cambió a: ${estado_nuevo}`
      };

      // Notificar al cliente
      if (cita.id_usuario_cliente) {
        await this.create({
          id_usuario: cita.id_usuario_cliente,
          tipo: 'cita',
          titulo: notif.titulo,
          mensaje: notif.mensaje,
          id_cita: id_cita,
          leida: false
        });
      }

      // Notificar al tatuador si está asignado y el cambio es relevante
      if (cita.id_usuario_tatuador && ['confirmada', 'cancelada'].includes(estado_nuevo)) {
        const mensajesTatuador = {
          confirmada: {
            titulo: '✅ Cliente confirmó cita',
            mensaje: `${cita.cliente_nombre || 'Cliente'} confirmó la cita del ${cita.fecha_hora_inicio ? new Date(cita.fecha_hora_inicio).toLocaleString('es-ES') : 'fecha programada'}.`
          },
          cancelada: {
            titulo: '❌ Cita cancelada',
            mensaje: `La cita con ${cita.cliente_nombre || 'cliente'} ha sido cancelada.`
          }
        };

        const notifTat = mensajesTatuador[estado_nuevo];
        if (notifTat) {
          await this.create({
            id_usuario: cita.id_usuario_tatuador,
            tipo: 'cita',
            titulo: notifTat.titulo,
            mensaje: notifTat.mensaje,
            id_cita: id_cita,
            leida: false
          });
        }
      }

    } catch (err) {
      console.error('Error al crear notificación de cita:', err);
      // No lanzar error para no interrumpir el flujo principal
    }
  }
}

module.exports = Notificaciones;
