const db = require('../config/db');
const Usuario = require('./Usuario');

class Cliente {
  static async exists(id) {
    const [rows] = await db.execute('SELECT 1 FROM clientes WHERE id_usuario = ?', [id]);
    return rows.length > 0;
  }

  static async create(id, data) {
    await db.execute(`
      INSERT INTO clientes (
        id_usuario, nombre, primer_apellido, segundo_apellido,
        telefono, direccion, fecha_naci, nickname
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      id,
      data.nombre,
      data.primer_apellido || '',
      data.segundo_apellido || '',
      data.telefono || '',
      data.direccion || '',
      data.fecha_naci,
      data.nickname || null
    ]);
  }

  static async getAll() {
    const [rows] = await db.execute(`
      SELECT u.id_usuario, u.email, u.estado,
             c.nombre, c.primer_apellido, c.segundo_apellido,
             c.telefono, c.direccion, c.fecha_naci, c.nickname
      FROM usuarios u
      JOIN usuario_roles ur ON ur.id_usuario = u.id_usuario
      JOIN roles r ON r.id_rol = ur.id_rol AND r.nombre = 'cliente'
      LEFT JOIN clientes c ON c.id_usuario = u.id_usuario
    `);
    return rows;
  }

  static async getById(id_usuario) {
    const [rows] = await db.execute(`
      SELECT u.id_usuario, u.email, u.estado,
             c.nombre, c.primer_apellido, c.segundo_apellido,
             c.telefono, c.direccion, c.fecha_naci, c.nickname
      FROM usuarios u
      LEFT JOIN clientes c ON c.id_usuario = u.id_usuario
      WHERE u.id_usuario = ?
    `, [id_usuario]);
    return rows[0] || null;
  }

  static async update(id_usuario, data) {
    await db.execute(`
      UPDATE clientes SET
        nombre = ?,
        primer_apellido = ?,
        segundo_apellido = ?,
        telefono = ?,
        direccion = ?,
        fecha_naci = ?,
        nickname = ?
      WHERE id_usuario = ?
    `, [
      data.nombre,
      data.primer_apellido || '',
      data.segundo_apellido || '',
      data.telefono || '',
      data.direccion || '',
      data.fecha_naci,
      data.nickname || null,
      id_usuario
    ]);
  }

  static async delete(id_usuario) {
    // Soft delete: desactivar usuario
    await db.execute('UPDATE usuarios SET estado = ? WHERE id_usuario = ?', ['inactivo', id_usuario]);
  }

  static async createWithUser(authData, clienteData) {
    // Crea usuario con rol 'cliente' y su perfil de cliente
    const { email, clave } = authData;
    const nuevo = await Usuario.create(email, clave, 'cliente');
    await this.create(nuevo.id_usuario, clienteData);
    return { id_usuario: nuevo.id_usuario };
  }
}

module.exports = Cliente;