// src/models/ReportesFinancieros.js
const db = require('../config/db');

class ReportesFinancieros {

  // Reporte general de ingresos por período
  static async getIngresosPorPeriodo(fechaInicio, fechaFin, tipoPeriodo = 'dia') {
    let groupByClause = '';
    let dateFormat = '';

    switch (tipoPeriodo) {
      case 'dia':
        groupByClause = 'DATE(c.fecha_hora_inicio)';
        dateFormat = '%Y-%m-%d';
        break;
      case 'semana':
        groupByClause = 'YEARWEEK(c.fecha_hora_inicio)';
        dateFormat = '%Y-W%u';
        break;
      case 'mes':
        groupByClause = 'DATE_FORMAT(c.fecha_hora_inicio, "%Y-%m")';
        dateFormat = '%Y-%m';
        break;
      case 'anio':
        groupByClause = 'YEAR(c.fecha_hora_inicio)';
        dateFormat = '%Y';
        break;
      default:
        groupByClause = 'DATE(c.fecha_hora_inicio)';
        dateFormat = '%Y-%m-%d';
    }

    const query = `
      SELECT
        DATE_FORMAT(c.fecha_hora_inicio, '${dateFormat}') as periodo,
        COUNT(*) as total_citas,
        SUM(c.precio) as ingresos_totales,
        SUM(CASE WHEN c.pago_estado = 'pagado' THEN c.precio ELSE 0 END) as ingresos_pagados,
        SUM(CASE WHEN c.pago_estado = 'pendiente' THEN c.precio ELSE 0 END) as ingresos_pendientes,
        AVG(c.precio) as promedio_por_cita
      FROM citas c
      WHERE c.fecha_hora_inicio BETWEEN ? AND ?
        AND c.estado = 'realizada'
      GROUP BY ${groupByClause}
      ORDER BY ${groupByClause}
    `;

    const [rows] = await db.execute(query, [fechaInicio, fechaFin]);
    return rows;
  }

  // Reporte de ingresos por tatuador
  static async getIngresosPorTatuador(fechaInicio, fechaFin) {
    const query = `
      SELECT
        u.email as tatuador_email,
        CONCAT(t.nombre, ' (', t.nombre_artistico, ')') as tatuador_nombre,
        COUNT(c.id_cita) as total_citas,
        SUM(c.precio) as ingresos_totales,
        SUM(CASE WHEN c.pago_estado = 'pagado' THEN c.precio ELSE 0 END) as ingresos_pagados,
        AVG(c.precio) as promedio_por_cita,
        COUNT(CASE WHEN c.pago_estado = 'pagado' THEN 1 END) as citas_pagadas,
        COUNT(CASE WHEN c.pago_estado = 'pendiente' THEN 1 END) as citas_pendientes
      FROM citas c
      INNER JOIN usuarios u ON c.id_usuario_tatuador = u.id_usuario
      LEFT JOIN tatuadores t ON u.id_usuario = t.id_usuario
      WHERE c.fecha_hora_inicio BETWEEN ? AND ?
        AND c.estado = 'realizada'
      GROUP BY c.id_usuario_tatuador, u.email, t.nombre, t.nombre_artistico
      ORDER BY ingresos_totales DESC
    `;

    const [rows] = await db.execute(query, [fechaInicio, fechaFin]);
    return rows;
  }

  // Reporte de servicios más populares
  static async getServiciosMasPopulares(fechaInicio, fechaFin) {
    const query = `
      SELECT
        s.nombre as servicio,
        s.descripcion,
        COUNT(c.id_cita) as veces_solicitado,
        SUM(c.precio) as ingresos_totales,
        AVG(c.precio) as precio_promedio,
        s.precio as precio_base
      FROM citas c
      INNER JOIN servicios s ON c.id_servicio = s.id_servicio
      WHERE c.fecha_hora_inicio BETWEEN ? AND ?
        AND c.estado = 'realizada'
      GROUP BY c.id_servicio, s.nombre, s.descripcion, s.precio
      ORDER BY veces_solicitado DESC, ingresos_totales DESC
    `;

    const [rows] = await db.execute(query, [fechaInicio, fechaFin]);
    return rows;
  }

  // Reporte de ganancias netas (ingresos - costos)
  static async getGananciasNetas(fechaInicio, fechaFin) {
    const query = `
      SELECT
        COUNT(*) as total_citas,
        SUM(precio) as ingresos_brutos,
        SUM(CASE WHEN pago_estado = 'pagado' THEN precio ELSE 0 END) as ingresos_efectivos,
        SUM(CASE WHEN pago_estado = 'pendiente' THEN precio ELSE 0 END) as ingresos_pendientes,
        AVG(precio) as promedio_por_cita,
        MIN(precio) as precio_minimo,
        MAX(precio) as precio_maximo,
        SUM(CASE WHEN precio >= 200000 THEN precio ELSE 0 END) as ingresos_tatuajes_grandes,
        COUNT(CASE WHEN precio >= 200000 THEN 1 END) as cantidad_tatuajes_grandes
      FROM citas
      WHERE fecha_hora_inicio BETWEEN ? AND ?
        AND estado = 'realizada'
    `;

    const [rows] = await db.execute(query, [fechaInicio, fechaFin]);
    return rows[0];
  }

  // Reporte de métricas generales
  static async getMetricasGenerales(fechaInicio, fechaFin) {
    const query = `
      SELECT
        COUNT(*) as total_citas,
        COUNT(DISTINCT id_usuario_cliente) as clientes_unicos,
        COUNT(DISTINCT id_usuario_tatuador) as tatuadores_activos,
        SUM(precio) as ingresos_brutos,
        AVG(precio) as promedio_por_cita,
        MIN(fecha_hora_inicio) as primera_cita,
        MAX(fecha_hora_inicio) as ultima_cita,
        COUNT(CASE WHEN estado = 'solicitud' THEN 1 END) as citas_solicitud,
        COUNT(CASE WHEN estado = 'programada' THEN 1 END) as citas_programadas,
        COUNT(CASE WHEN estado = 'confirmada' THEN 1 END) as citas_confirmadas,
        COUNT(CASE WHEN estado = 'realizada' THEN 1 END) as citas_realizadas,
        COUNT(CASE WHEN estado = 'cancelada' THEN 1 END) as citas_canceladas
      FROM citas
      WHERE fecha_hora_inicio BETWEEN ? AND ?
    `;

    const [rows] = await db.execute(query, [fechaInicio, fechaFin]);
    return rows[0];
  }

  // Reporte de tendencias de citas
  static async getTendenciasCitas(fechaInicio, fechaFin) {
    const query = `
      SELECT
        DATE(fecha_hora_inicio) as fecha,
        COUNT(*) as citas_dia,
        SUM(precio) as ingresos_dia,
        AVG(precio) as promedio_dia
      FROM citas
      WHERE fecha_hora_inicio BETWEEN ? AND ?
      GROUP BY DATE(fecha_hora_inicio)
      ORDER BY fecha
    `;

    const [rows] = await db.execute(query, [fechaInicio, fechaFin]);
    return rows;
  }

  // Reporte de pagos por método
  static async getPagosPorMetodo(fechaInicio, fechaFin) {
    const query = `
      SELECT
        p.metodo as metodo_pago,
        COUNT(*) as total_pagos,
        SUM(p.monto) as monto_total,
        AVG(p.monto) as promedio_pago,
        COUNT(CASE WHEN p.estado = 'completado' THEN 1 END) as pagos_exitosos,
        COUNT(CASE WHEN p.estado = 'pendiente' THEN 1 END) as pagos_pendientes,
        COUNT(CASE WHEN p.estado = 'fallido' THEN 1 END) as pagos_fallidos
      FROM pagos p
      INNER JOIN citas c ON p.id_cita = c.id_cita
      WHERE c.fecha_hora_inicio BETWEEN ? AND ?
      GROUP BY p.metodo
      ORDER BY monto_total DESC
    `;

    const [rows] = await db.execute(query, [fechaInicio, fechaFin]);
    return rows;
  }

  // Reporte de citas por estado
  static async getCitasPorEstado(fechaInicio, fechaFin) {
    const query = `
      SELECT
        estado,
        COUNT(*) as cantidad,
        SUM(precio) as ingresos_totales,
        AVG(precio) as promedio_precio,
        MIN(fecha_hora_inicio) as primera_fecha,
        MAX(fecha_hora_inicio) as ultima_fecha
      FROM citas
      WHERE fecha_hora_inicio BETWEEN ? AND ?
      GROUP BY estado
      ORDER BY cantidad DESC
    `;

    const [rows] = await db.execute(query, [fechaInicio, fechaFin]);
    return rows;
  }
}

module.exports = ReportesFinancieros;
