# 📊 Reportes Financieros Avanzados - SkinCodeIA

## 🚀 Funcionalidades Implementadas

### **Sistema de Reportes Completo**
- ✅ **Reportes por períodos** (día, semana, mes, año)
- ✅ **Ingresos por tatuador**
- ✅ **Servicios más populares**
- ✅ **Ganancias netas**
- ✅ **Métricas generales**
- ✅ **Tendencias de citas**
- ✅ **Pagos por método**
- ✅ **Exportación a CSV**

---

## 🔗 **URLs de los Reportes**

**Base URL:** `http://localhost:3000/api/financieros`

### **📈 Dashboard Financiero**
```
GET /api/financieros/dashboard?fechaInicio=2024-01-01&fechaFin=2024-12-31
```

### **💰 Ingresos por Período**
```
GET /api/financieros/ingresos/periodo?fechaInicio=2024-01-01&fechaFin=2024-12-31&tipoPeriodo=dia
```
**Tipos de período:** `dia`, `semana`, `mes`, `anio`

### **👨‍🎨 Ingresos por Tatuador**
```
GET /api/financieros/ingresos/tatuador?fechaInicio=2024-01-01&fechaFin=2024-12-31
```

### **⭐ Servicios Más Populares**
```
GET /api/financieros/servicios/populares?fechaInicio=2024-01-01&fechaFin=2024-12-31
```

### **📊 Métricas Generales**
```
GET /api/financieros/metricas-generales?fechaInicio=2024-01-01&fechaFin=2024-12-31
```

### **📈 Tendencias de Citas**
```
GET /api/financieros/tendencias/citas?fechaInicio=2024-01-01&fechaFin=2024-12-31
```

### **💳 Pagos por Método**
```
GET /api/financieros/pagos/metodo?fechaInicio=2024-01-01&fechaFin=2024-12-31
```

### **📋 Citas por Estado**
```
GET /api/financieros/citas/estado?fechaInicio=2024-01-01&fechaFin=2024-12-31
```

### **📄 Exportar a CSV**
```
GET /api/financieros/exportar/csv?tipo=ingresos-periodo&fechaInicio=2024-01-01&fechaFin=2024-12-31
```
**Tipos disponibles:** `ingresos-periodo`, `ingresos-tatuador`, `servicios-populares`, `metricas-generales`

---

## 🔐 **Autenticación**

**Todos los endpoints requieren:**
- ✅ **Header:** `Authorization: Bearer TU_TOKEN_JWT`
- ✅ **Solo usuarios con rol "soporte"** pueden acceder

---

## 📊 **Ejemplos de Uso**

### **1. Obtener Dashboard Financiero**
```javascript
const response = await fetch('http://localhost:3000/api/financieros/dashboard?fechaInicio=2024-10-01&fechaFin=2024-10-31', {
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  }
});

const dashboard = await response.json();
console.log(dashboard.data.metricasGenerales);
```

### **2. Exportar Reporte a CSV**
```javascript
const response = await fetch('http://localhost:3000/api/financieros/exportar/csv?tipo=ingresos-tatuador&fechaInicio=2024-01-01&fechaFin=2024-12-31', {
  headers: {
    'Authorization': `Bearer ${token}`
  }
});

// Guardar como archivo CSV
const blob = await response.blob();
const url = window.URL.createObjectURL(blob);
const a = document.createElement('a');
a.href = url;
a.download = 'reporte-ingresos-tatuadores.csv';
a.click();
```

---

## 🎯 **Datos de Reportes Disponibles**

### **📈 Métricas Generales**
- Total de citas realizadas
- Número de clientes únicos
- Tatuadores activos
- Ingresos brutos y efectivos
- Promedio por cita
- Primera y última cita
- Citas por estado

### **💰 Ingresos por Tatuador**
- Email y nombre del tatuador
- Total de citas realizadas
- Ingresos totales generados
- Promedio por cita
- Citas pagadas vs pendientes

### **⭐ Servicios Más Populares**
- Servicio más solicitado
- Ingresos generados por servicio
- Veces que se realizó cada servicio
- Precio promedio vs precio base

### **📊 Tendencias de Citas**
- Citas por día
- Ingresos diarios
- Promedio diario

### **💳 Pagos por Método**
- Métodos de pago utilizados
- Montos totales por método
- Éxito de pagos por método

---

## 📋 **Preparación de Datos**

### **1. Ejecutar Script de Datos de Ejemplo**
```sql
-- En phpMyAdmin → skincodeia1 → SQL
SOURCE /ruta/a/DATOS_EJEMPLO_REPORTES.sql;
```

### **2. Verificar Servicios con Precios**
```sql
SELECT id_servicio, nombre, precio FROM servicios WHERE activo = 1;
```

---

## 🚀 **Próximos Pasos Sugeridos**

### **Mejoras Futuras**
1. **Gráficos interactivos** con Chart.js
2. **Filtros avanzados** por tatuador, servicio, cliente
3. **Reportes comparativos** entre períodos
4. **Alertas automáticas** de métricas
5. **Dashboard visual** en el frontend
6. **Exportación a PDF**

### **Funcionalidades Adicionales**
- Reportes de productividad por tatuador
- Análisis de tendencias estacionales
- Predicciones de ingresos
- Reportes de clientes frecuentes

---

## ✅ **Estado Actual**

- ✅ **Backend completo** implementado
- ✅ **Modelos y consultas** optimizadas
- ✅ **Controladores** con validaciones
- ✅ **Rutas protegidas** con autenticación
- ✅ **Exportación CSV** funcional
- ✅ **Datos de ejemplo** incluidos

**¡El sistema de reportes financieros avanzados está completamente operativo!** 🎉

---

**Fecha:** Octubre 16, 2025
**Estado:** ✅ Completamente Funcional
**Acceso:** Requiere autenticación como administrador
