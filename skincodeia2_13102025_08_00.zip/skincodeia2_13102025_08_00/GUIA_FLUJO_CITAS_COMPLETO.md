# 📋 Guía Completa: Flujo de Creación y Gestión de Citas

## 🎯 **Visión General del Sistema**

SkinCodeIA es un **CRM completo para estudios de tatuajes** que gestiona todo el ciclo de vida de las citas, desde la solicitud inicial hasta la realización y seguimiento.

---

## 👥 **Actores del Sistema**

### **1. Cliente 👤**
- Usuario final que solicita tatuajes/piercings
- Puede crear solicitudes, confirmar citas, recibir notificaciones

### **2. Tatuador 👨‍🎨**
- Profesional que realiza los servicios
- Gestiona su agenda, confirma disponibilidad, registra trabajos

### **3. Administrador/Soporte 🛠️**
- Gestiona el sistema completo
- Acceso a reportes financieros, configuración general

---

## 📊 **Estados de las Citas**

| Estado | Descripción | Acción Trigger |
|--------|-------------|----------------|
| `solicitud` | Cliente crea solicitud inicial | Cliente envía formulario |
| `programada` | Administrador asigna fecha/hora | Soporte agenda la cita |
| `confirmada` | Cliente confirma asistencia | Cliente acepta propuesta |
| `realizada` | Servicio completado | Tatuador marca como hecho |
| `cancelada` | Cita anulada | Cliente o soporte cancela |

---

## 🔄 **Flujo Completo de Creación de Cita**

### **FASE 1: Solicitud Inicial (Cliente)**

#### **Paso 1.1: Cliente accede al sistema**
```
🌐 Cliente → http://localhost:3000
📝 Cliente hace login con: cliente@test.com / 123456
🎯 Cliente navega a "Crear Cita" o "Solicitar Servicio"
```

#### **Paso 1.2: Cliente selecciona servicio**
```
📋 Cliente ve catálogo de servicios disponibles:
   • Tatuaje Mini (1-5cm) - $80,000
   • Tatuaje Pequeño (5-10cm) - $150,000
   • Tatuaje Mediano (10-20cm) - $300,000
   • Piercing Lóbulo - $30,000
   • Piercing Helix - $40,000

✅ Cliente selecciona servicio deseado
📝 Cliente agrega notas específicas del diseño
🖼️ Cliente sube imagen de referencia (opcional)
```

#### **Paso 1.3: Sistema procesa solicitud**
```
💾 Sistema guarda en tabla 'citas':
   • id_usuario_cliente = ID del cliente
   • id_servicio = Servicio seleccionado
   • precio = Obtiene precio automáticamente del servicio
   • estado = 'solicitud'
   • notas_cliente = Notas del cliente
   • url_referencia = Imagen subida

🔔 Sistema crea notificación automática para soporte
📧 Email automático: "Nueva solicitud recibida"
```

---

### **FASE 2: Procesamiento (Administrador)**

#### **Paso 2.1: Soporte revisa solicitudes**
```
🔍 Soporte accede a dashboard administrativo
📋 Ve sección "Solicitudes Pendientes"
📖 Revisa detalles: servicio, notas, imagen referencia
👤 Verifica perfil del cliente
```

#### **Paso 2.2: Soporte asigna tatuador**
```
👨‍🎨 Soporte selecciona tatuador disponible
📅 Verifica disponibilidad del tatuador
⏰ Propone fecha y hora específica
💰 Confirma precio final (puede ajustar)
📝 Agrega notas internas para tatuador
```

#### **Paso 2.3: Sistema programa la cita**
```
💾 Sistema actualiza tabla 'citas':
   • id_usuario_tatuador = ID del tatuador asignado
   • fecha_hora_inicio = Fecha/hora programada
   • fecha_hora_fin = Fecha/hora estimada fin
   • estado = 'programada'
   • notas_internas = Notas del soporte

🔔 Crea notificaciones automáticas:
   • Para cliente: "Cita programada - revisar detalles"
   • Para tatuador: "Nueva cita asignada"
```

---

### **FASE 3: Confirmación (Cliente)**

#### **Paso 3.1: Cliente recibe notificación**
```
📱 Cliente recibe notificación push/email:
   "Tu cita ha sido programada para [fecha] a las [hora]"

📧 Cliente puede recibir detalles por:
   • Email automático
   • Notificación en la plataforma
   • Posiblemente SMS/WhatsApp
```

#### **Paso 3.2: Cliente confirma asistencia**
```
✅ Cliente accede a "Mis Citas"
📋 Ve detalles: fecha, hora, tatuador, precio
👍 Cliente confirma asistencia
❌ Cliente puede solicitar reagendar (opcional)

💾 Sistema actualiza:
   • estado = 'confirmada'

🔔 Notificaciones automáticas:
   • Tatuador: "Cliente confirmó cita"
   • Soporte: "Cita confirmada"
```

---

### **FASE 4: Realización (Tatuador)**

#### **Paso 4.1: Tatuador se prepara**
```
📅 Día de la cita, tatuador recibe recordatorio
👤 Tatuador verifica materiales necesarios
📋 Tatuador revisa notas del cliente y referencia
🏢 Tatuador prepara estación de trabajo
```

#### **Paso 4.2: Cliente llega al estudio**
```
🕐 Cliente llega puntual al estudio
✅ Tatuador confirma llegada
💳 Si aplica, se procesa pago inicial
📝 Tatuador registra cualquier cambio en el diseño
```

#### **Paso 4.3: Servicio se realiza**
```
🎨 Tatuador realiza el trabajo
📷 Durante proceso, puede tomar fotos del progreso
💬 Comunicación constante con cliente sobre ajustes
⏱️ Respeta tiempos establecidos
```

#### **Paso 4.4: Cita completada**
```
✅ Tatuador marca cita como "realizada"
💾 Sistema registra:
   • estado = 'realizada'
   • pago_estado = 'pagado' o 'pendiente'
   • pago_fecha = Fecha del pago

🔔 Notificaciones automáticas:
   • Cliente: "Cita completada exitosamente"
   • Soporte: "Nueva cita completada"

📊 Sistema actualiza métricas:
   • Ingresos del día
   • Productividad del tatuador
   • Satisfacción del cliente
```

---

### **FASE 5: Seguimiento (Sistema)**

#### **Paso 5.1: Cliente recibe cuidados post-servicio**
```
📧 Cliente recibe guía de cuidados automáticos:
   • Cómo cuidar el tatuaje/piercing
   • Productos recomendados
   • Cuándo volver para retoques
   • Contacto para dudas
```

#### **Paso 5.2: Sistema registra en portafolio**
```
📸 Si el tatuador tomó fotos, se agregan al portafolio
🏷️ Se categoriza el trabajo realizado
⭐ Cliente puede dejar reseña (funcionalidad futura)
📈 Sistema actualiza estadísticas del tatuador
```

#### **Paso 5.3: Recordatorios de seguimiento**
```
📅 Sistema programa recordatorios:
   • 24 horas: "¿Cómo va la cicatrización?"
   • 1 semana: "Recuerda cuidados"
   • 1 mes: "¿Satisfecho con el resultado?"
   • 3 meses: "Posible retoque si es necesario"
```

---

## 🔧 **Flujos Especiales**

### **Caso 1: Cancelación por Cliente**
```
❌ Cliente solicita cancelación
📞 Sistema notifica inmediatamente al tatuador
🔄 Si es dentro del plazo, reembolso automático
📝 Razón de cancelación se registra
📊 Estadísticas de cancelación se actualizan
```

### **Caso 2: Reagendamiento**
```
🔄 Cliente solicita cambio de fecha
👨‍🎨 Tatuador confirma disponibilidad alternativa
📅 Nueva fecha se propone y confirma
🔄 Proceso de reprogramación se registra
```

### **Caso 3: Problemas durante el servicio**
```
⚠️ Si surge algún problema durante la sesión
📞 Sistema permite comunicación inmediata
🔄 Puede pausar/reanudar la sesión
📝 Incidentes se registran para mejora continua
```

---

## 📊 **Reportes y Métricas**

### **Para Administradores:**
```
📈 Ingresos diarios/semanales/mensuales
👥 Clientes nuevos vs recurrentes
👨‍🎨 Productividad por tatuador
⭐ Servicios más populares
💰 Tasa de conversión (solicitudes → citas realizadas)
```

### **Para Tatuadores:**
```
📅 Su agenda personal
💰 Sus ingresos individuales
⭐ Calificaciones y reseñas
📈 Su portafolio de trabajos
⏱️ Tiempo promedio por tipo de servicio
```

---

## 🚀 **Automatizaciones del Sistema**

### **Notificaciones Automáticas:**
- ✅ Nueva solicitud recibida
- ✅ Cita programada
- ✅ Cliente confirmó asistencia
- ✅ Recordatorios de citas
- ✅ Cita completada
- ✅ Seguimientos post-servicio

### **Procesos Automatizados:**
- ✅ Cálculo automático de precios
- ✅ Asignación inteligente de tatuadores
- ✅ Generación automática de reportes
- ✅ Backup automático de datos
- ✅ Sincronización de calendarios

---

## 📱 **Interfaz de Usuario**

### **Cliente:**
```
🏠 Dashboard → Mis Citas → Crear Nueva
📋 Ver solicitudes pendientes
📅 Ver citas programadas/confirmadas
💬 Comunicación con tatuador
⭐ Dejar reseñas
📊 Historial completo
```

### **Tatuador:**
```
📅 Agenda personal
💼 Portafolio de trabajos
💰 Seguimiento de ingresos
👥 Gestión de clientes
📊 Estadísticas personales
```

### **Administrador:**
```
📊 Dashboard financiero completo
👥 Gestión de usuarios
📋 Todas las citas del estudio
💰 Reportes avanzados
⚙️ Configuración del sistema
```

---

## ✅ **Estado Actual del Sistema**

- ✅ **Flujo básico implementado** y funcionando
- ✅ **Notificaciones automáticas** operativas
- ✅ **Sistema de estados** completo
- ✅ **Reportes financieros** disponibles
- ✅ **Gestión de usuarios** por roles
- 🚧 **Interfaz visual** (pendiente desarrollo frontend completo)

---

**🎯 Esta guía representa el flujo completo implementado en SkinCodeIA, desde la solicitud hasta el seguimiento post-servicio.**
