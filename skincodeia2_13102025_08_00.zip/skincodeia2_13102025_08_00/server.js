const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/api/auth', require('./src/routes/auth'));
app.use('/api/perfil', require('./src/routes/perfil'));
app.use('/api/tatuajes', require('./src/routes/tatuajes'));
app.use('/api/citas', require('./src/routes/citas'));
app.use('/api/servicios', require('./src/routes/servicios'));
app.use('/api/tatuadores', require('./src/routes/tatuadores'));
app.use('/api/clientes', require('./src/routes/clientes'));
app.use('/api/pagos', require('./src/routes/pagos'));
app.use('/api/notificaciones', require('./src/routes/notificaciones'));
app.use('/api/financieros', require('./src/routes/financieros'));


app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});